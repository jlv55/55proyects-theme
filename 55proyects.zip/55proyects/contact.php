<?php
$fname = $_POST['name'];
$email = $_POST['email'];
$message = $_POST['message'];
$subject = 'Algún pesao que vio la web';
$messages = 'From site jlv55.com: '.$name.'</br>'.$email.'</br>'.$message.'</br>';
$headers  = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=utf-8' . "\r\n";

mail('jlv@55proyects.com, $email', $subject, $messages, $headers);
?>