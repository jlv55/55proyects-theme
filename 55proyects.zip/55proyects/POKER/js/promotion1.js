$(document).ready(function(){  
	
		$.backstretch([
            /*Change the images url for change the background images*/
            /*Add your images to the images directory and background subdirectory*/
     "images/poker.png"
  ], {duration: 3000, fade: 1500});

});